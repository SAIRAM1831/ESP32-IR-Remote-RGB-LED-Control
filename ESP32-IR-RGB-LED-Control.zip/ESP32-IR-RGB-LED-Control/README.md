# ESP32 IR Remote-Controlled RGB LED with LCD

A MicroPython project that uses an ESP32 and an infrared (IR) remote to control an RGB LED. A 16×2 I2C LCD displays the selected colour.

## Features

- Select LED colours using an IR remote
- Display the selected colour on a 16×2 LCD
- Control red, green, and blue LED channels independently
- Mix channels to create yellow, cyan, and magenta

## Hardware Used

- ESP32 development board
- RGB LED (or compatible RGB LED module)
- IR receiver and compatible IR remote
- 16×2 LCD with I2C backpack
- Jumper wires and suitable current-limiting resistors

## Pin Connections

| Component | ESP32 GPIO |
|---|---:|
| LCD SDA | GPIO 21 |
| LCD SCL | GPIO 22 |
| RGB red channel | GPIO 18 |
| RGB green channel | GPIO 19 |
| RGB blue channel | GPIO 23 |
| IR receiver signal | GPIO 27 |

Check your actual board and module wiring before powering the circuit. Use appropriate current-limiting resistors for discrete LEDs.

## Remote Button Mapping

The code expects these decoded IR values:

| Remote button | Action |
|---|---|
| 1 | Red |
| 2 | Green |
| 3 | Blue |
| 4 | Yellow (red + green) |
| 5 | Cyan (green + blue) |
| 6 | Magenta (red + blue) |
| 0 | Turn all RGB channels off |

IR codes can vary between remotes. If a button does not work, check the decoded value from your remote and update the code accordingly.

## Files

- `main.py` — main MicroPython program
- `images/project-photo.jpg` — photo of the hardware
- `i2c_lcd.py` — required LCD driver (add the compatible driver you use)
- `ir_rx.py` — required IR receiver library (add the compatible library you use)

The `i2c_lcd.py` and `ir_rx.py` modules are imported by `main.py` and must be installed on the ESP32. They are not bundled here because the exact library versions and their licenses have not been verified.

## How to Run

1. Install MicroPython on the ESP32.
2. Copy compatible `i2c_lcd.py` and `ir_rx.py` modules to the ESP32.
3. Copy `main.py` to the ESP32 using Thonny or another MicroPython tool.
4. Confirm the I2C LCD address (the example uses `0x27`).
5. Wire the RGB LED and IR receiver to the GPIO pins listed above.
6. Reset the ESP32 and test the remote buttons.

## Project Photo

See [`images/project-photo.jpg`](images/project-photo.jpg).

## Notes

This is an educational prototype. Verify wiring, pin assignments, library compatibility, and IR codes for your specific hardware before use.
