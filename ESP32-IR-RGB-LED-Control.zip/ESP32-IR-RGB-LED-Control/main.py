from machine import Pin, I2C
from ir_rx import NEC_16
from i2c_lcd import I2cLcd

# LCD Setup
i2c = I2C(0, scl=Pin(22), sda=Pin(21), freq=100000)
lcd = I2cLcd(i2c, 0x27, 2, 16)   # Change 0x27 if needed

# RGB LED Pins
red = Pin(18, Pin.OUT)
green = Pin(19, Pin.OUT)
blue = Pin(23, Pin.OUT)

def rgb_off():
    red.off()
    green.off()
    blue.off()

def show_color(name):
    lcd.clear()
    lcd.putstr("RGB Color:")
    lcd.move_to(0, 1)
    lcd.putstr(name)

def callback(data, ctrl):
    if data > 0:
        rgb_off()

        if data == 0x0a:      # 1
            red.on()
            show_color("RED")

        elif data == 0x1b:    # 2
            green.on()
            show_color("GREEN")

        elif data == 0x1f:    # 3
            blue.on()
            show_color("BLUE")

        elif data == 0x0c:    # 4
            red.on()
            green.on()
            show_color("YELLOW")

        elif data == 0x0d:    # 5
            green.on()
            blue.on()
            show_color("CYAN")

        elif data == 0x0e:    # 6
            red.on()
            blue.on()
            show_color("MAGENTA")

        elif data == 0x07:    # 0
            show_color("OFF")

# IR Receiver on GPIO27
ir = NEC_16(Pin(27, Pin.IN), callback)

lcd.clear()
lcd.putstr("IR RGB Ready")
